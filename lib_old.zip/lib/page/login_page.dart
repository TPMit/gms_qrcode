import 'package:flutter/material.dart';
import 'package:gms_mobile/page/home.dart';
import 'package:gms_mobile/model/post_auth_model.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

class LoginPage extends StatefulWidget {
  static String tag = 'login-page';
  @override
  _LoginPageState createState() => new _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  PostResult postResult;
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  String forgotpwurl = 'https://hris.tpm-facility.com/login/forgotpassword';

  void _forgotpwurl() async => await canLaunch(forgotpwurl)
      ? await launch(forgotpwurl)
      : throw 'Could not launch $forgotpwurl';

  void saveData() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setString("name", postResult.name);
    pref.setString("nik", postResult.nik);
    pref.setString("email", postResult.email);
    pref.setString("idsite", postResult.idsite);
    pref.setString("idposition", postResult.idposition);
  }

  getPermission() async {
    var cameraPermission = await Permission.camera.status;
    var locationPermission = await Permission.location.status;
    if (cameraPermission.isUndetermined) {
      await Permission.camera.request();
    }
    if (locationPermission.isUndetermined) {
      await Permission.location.request();
    }
  }

  @override
  void initState() {
    super.initState();
    getPermission();
  }

  @override
  Widget build(BuildContext context) {
    final logo = Hero(
      tag: 'hero',
      child: CircleAvatar(
        backgroundColor: Colors.transparent,
        radius: 48.0,
        child: Image.asset('assets/images/alogo.png'),
      ),
    );

    final email = TextFormField(
      keyboardType: TextInputType.emailAddress,
      autofocus: false,
      controller: emailController,
      decoration: InputDecoration(
        hintText: 'Email',
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
      ),
    );

    final password = TextFormField(
      autofocus: false,
      obscureText: true,
      controller: passwordController,
      decoration: InputDecoration(
        hintText: 'Password',
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
      ),
    );

    final loginButton = Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: Material(
        borderRadius: BorderRadius.circular(30.0),
        shadowColor: Color(0xffffb969),
        elevation: 5.0,
        child: MaterialButton(
          minWidth: 200.0,
          height: 42.0,
          onPressed: () {
            PostResult.connectToApi(
                    emailController.text.trim(), passwordController.text)
                .then((value) {
              postResult = value;
              if (postResult.email != null) {
                saveData();
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (BuildContext ctx) => Home()));
              } else {
                Fluttertoast.showToast(
                    msg: "tidak terdaftar",
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.CENTER,
                    timeInSecForIosWeb: 1,
                    backgroundColor: Colors.red,
                    textColor: Colors.white,
                    fontSize: 16.0);
              }
              setState(() {});
            });
          },
          color: Color(0xffffb969),
          child: Text('Log In', style: TextStyle(color: Colors.white)),
        ),
      ),
    );

    final forgotLabel = TextButton(
      child: Text(
        'Forgot password?',
        style: TextStyle(color: Colors.black54),
      ),
      onPressed: () {
        _forgotpwurl();
      },
    );

    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.only(left: 24.0, right: 24.0),
          children: <Widget>[
            logo,
            SizedBox(height: 48.0),
            email,
            SizedBox(height: 8.0),
            password,
            SizedBox(height: 24.0),
            loginButton,
            forgotLabel
          ],
        ),
      ),
    );
  }
}

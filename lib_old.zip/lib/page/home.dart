import 'package:flutter/material.dart';
import 'package:gms_mobile/menu/shift/shift_anggota.dart';
import 'package:gms_mobile/page/empty.dart';
import 'package:gms_mobile/page/login_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:gms_mobile/component/theme/light_colors.dart';
import 'package:gms_mobile/component/widgets/top_container.dart';
import 'package:gms_mobile/menu/absensi.dart';
import 'dart:math';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  SharedPreferences _prefs;
  String _name = "PT. Trimitra Putra Mandiri";
  String _idposition = "1";
  double value = 0;
  Text subheading(String title) {
    return Text(
      title,
      style: TextStyle(
          color: LightColors.kDarkBlue,
          fontSize: 20.0,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2),
    );
  }

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((prefs) {
      setState(() => this._prefs = prefs);
      this._name = this._prefs.get('name') ?? 'No Name';
      this._idposition = this._prefs.get('idposition') ?? '0';
    });
  }

  // static CircleAvatar calendarIcon() {
  //   return CircleAvatar(
  //     radius: 25.0,
  //     backgroundColor: LightColors.kGreen,
  //     child: Icon(
  //       Icons.calendar_today,
  //       size: 20.0,
  //       color: Colors.white,
  //     ),
  //   );
  // }
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: LightColors.kLightYellow,
        body: Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                LightColors.kLightYellow,
                LightColors.kDarkYellow
              ], begin: Alignment.bottomLeft, end: Alignment.topRight)),
            ),
            // NAVIGATION
            SafeArea(
                child: Container(
              width: 200.0,
              padding: EdgeInsets.all(8.0),
              child: Column(
                children: [
                  DrawerHeader(
                      child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                        child: CircleAvatar(
                          radius: 50.0,
                          backgroundImage: AssetImage(
                            'assets/images/avatar.png',
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Text(
                        _name,
                        style: TextStyle(fontSize: 15),
                      ),
                    ],
                  )),
                  Expanded(
                      child: ListView(
                    children: [
                      ListTile(
                        onTap: () {},
                        leading: Icon(Icons.home),
                        title: Text(
                          "Home",
                          style: TextStyle(),
                        ),
                      ),
                      ListTile(
                        onTap: () {},
                        leading: Icon(
                          Icons.person,
                        ),
                        title: Text(
                          "User",
                          style: TextStyle(),
                        ),
                      ),
                      ListTile(
                        onTap: () {
                          Navigator.of(context)
                              .push(MaterialPageRoute(builder: (context) {
                            return Listshift();
                          }));
                        },
                        leading: Icon(
                          Icons.settings,
                        ),
                        title: Text(
                          "Shift",
                          style: TextStyle(),
                        ),
                      ),
                      ListTile(
                        onTap: () {
                          setState(() {
                            _prefs.clear();
                            Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LoginPage()));
                          });
                        },
                        leading: Icon(
                          Icons.logout,
                        ),
                        title: Text(
                          "Logout",
                          style: TextStyle(),
                        ),
                      ),
                    ],
                  ))
                ],
              ),
            )),

            // wrap main screen
            TweenAnimationBuilder(
              tween: Tween<double>(begin: 0, end: value),
              duration: Duration(microseconds: 500),
              builder: (_, double val, __) {
                return (Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.001)
                    ..setEntry(0, 3, 200 * val)
                    ..rotateY((pi / 6) * val),
                  child: Scaffold(
                    body: Column(
                      children: <Widget>[
                        TopContainer(
                          height: 200,
                          width: width,
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          value == 0 ? value = 1 : value = 0;
                                        });
                                      },
                                      child: Icon(Icons.menu,
                                          color: LightColors.kDarkBlue,
                                          size: 30.0),
                                    ),
                                    Icon(Icons.notifications,
                                        color: LightColors.kDarkBlue,
                                        size: 25.0),
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 0, vertical: 0.0),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: <Widget>[
                                      Flexible(
                                        child: CircleAvatar(
                                          backgroundColor: LightColors.kBlue,
                                          radius: 35.0,
                                          backgroundImage: AssetImage(
                                            'assets/images/avatar.png',
                                          ),
                                        ),
                                      ),
                                      Flexible(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: <Widget>[
                                            Container(
                                              child: Text(
                                                _name,
                                                textAlign: TextAlign.end,
                                                style: TextStyle(
                                                  fontSize: 22.0,
                                                  color: LightColors.kDarkBlue,
                                                  fontWeight: FontWeight.w800,
                                                ),
                                              ),
                                            ),
                                            Container(
                                              child: Text(
                                                (_idposition == '2')
                                                    ? "Komandan Regu"
                                                    : "Security",
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                  fontSize: 16.0,
                                                  color: Colors.black45,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ),
                                            Container(
                                              child: ListTile(
                                                onTap: () {
                                                  setState(() {
                                                    _prefs.clear();
                                                    Navigator.pushReplacement(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                LoginPage()));
                                                  });
                                                },
                                                leading: Icon(
                                                  Icons.logout,
                                                ),
                                                title: Text(
                                                  "Logout",
                                                  style: TextStyle(),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              ]),
                        ),
                        Expanded(
                          child: SingleChildScrollView(
                            child: Column(
                              children: <Widget>[
                                Container(
                                  color: Colors.transparent,
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 20.0, vertical: 10.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      subheading('Quick Menus'),
                                      SizedBox(height: 5.0),
                                      Row(
                                        children: <Widget>[
                                          Menu(
                                            cardColor: LightColors.kGreen,
                                            cardIcon: Icons.exit_to_app,
                                            title: 'Absen Masuk',
                                            subtitle: 'Sebelum Jam Kerja',
                                            screenWidget: Absensi(
                                              inOut: '1',
                                            ),
                                          ),
                                          SizedBox(width: 20.0),
                                          Menu(
                                            cardColor: LightColors.kRed,
                                            cardIcon: Icons.redo,
                                            title: 'Absen Keluar',
                                            subtitle: 'Sesudah Jam Kerja',
                                            screenWidget: Absensi(
                                              inOut: '0',
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: <Widget>[
                                          Menu(
                                            cardColor: LightColors.kDarkYellow,
                                            cardIcon:
                                                Icons.notification_important,
                                            title: 'SOS',
                                            subtitle: 'Emergency Contact',
                                            screenWidget: Empty(),
                                          ),
                                          SizedBox(width: 20.0),
                                          Menu(
                                            cardColor: LightColors.kBlue,
                                            cardIcon: Icons.checklist_outlined,
                                            title: 'Absensi',
                                            subtitle: 'Periksa Absensi',
                                            screenWidget: Empty(),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: <Widget>[
                                          Menu(
                                            cardColor: LightColors.kDarkBlue,
                                            cardIcon:
                                                Icons.local_activity,
                                            title: 'Aktivitas',
                                            subtitle: 'Periksa Aktivitas',
                                            screenWidget: Empty(),
                                          ),
                                          SizedBox(width: 20.0),
                                          Menu(
                                            cardColor: LightColors.kGreen,
                                            cardIcon: Icons.location_history,
                                            title: 'Jumlah Pengunjung',
                                            subtitle: '',
                                            screenWidget: Empty(),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    //),
                  ),
                ));
              },
            )
          ],
        ));
  }
}

class Menu extends StatelessWidget {
  final Color cardColor;
  final IconData cardIcon;
  final String title;
  final String subtitle;
  final Widget screenWidget;

  Menu(
      {this.cardColor,
      this.cardIcon,
      this.title,
      this.subtitle,
      this.screenWidget});
  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 1,
      child: GestureDetector(
        onTap: () {
          Route route = MaterialPageRoute(builder: (context) {
            return screenWidget;
          });

          Navigator.of(context).push(route);
        },
        child: Container(
          margin: EdgeInsets.symmetric(vertical: 10.0),
          padding: EdgeInsets.all(15.0),
          height: 200,
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(30.0),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Icon(
                  cardIcon,
                  size: 85,
                  color: Colors.white70,
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 14.0,
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 12.0,
                      color: Colors.white54,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:gms_mobile/component/theme/light_colors.dart';
import 'package:gms_mobile/component/widgets/top_container.dart';
import 'package:gms_mobile/menu/absensi.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  SharedPreferences _prefs;
  String _name = "PT. Trimitra Putra Mandiri";

  Text subheading(String title) {
    return Text(
      title,
      style: TextStyle(
          color: LightColors.kDarkBlue,
          fontSize: 20.0,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2),
    );
  }

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((prefs) {
      setState(() => this._prefs = prefs);
      this._name = this._prefs.get('name') ?? 'No Name';
    });
  }

  // static CircleAvatar calendarIcon() {
  //   return CircleAvatar(
  //     radius: 25.0,
  //     backgroundColor: LightColors.kGreen,
  //     child: Icon(
  //       Icons.calendar_today,
  //       size: 20.0,
  //       color: Colors.white,
  //     ),
  //   );
  // }
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: LightColors.kLightYellow,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            TopContainer(
              height: 200,
              width: width,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Icon(Icons.menu,
                            color: LightColors.kDarkBlue, size: 30.0),
                        Icon(Icons.notifications,
                            color: LightColors.kDarkBlue, size: 25.0),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 0, vertical: 0.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          CircleAvatar(
                            backgroundColor: LightColors.kBlue,
                            radius: 35.0,
                            backgroundImage: AssetImage(
                              'assets/avatar.png',
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Container(
                                child: Text(
                                  _name,
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    fontSize: 22.0,
                                    color: LightColors.kDarkBlue,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  'Security',
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    fontSize: 16.0,
                                    color: Colors.black45,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    )
                  ]),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    Container(
                      color: Colors.transparent,
                      padding: EdgeInsets.symmetric(
                          horizontal: 20.0, vertical: 10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          subheading('Quick Menus'),
                          SizedBox(height: 5.0),
                          Row(
                            children: <Widget>[
                              Menu(
                                cardColor: LightColors.kGreen,
                                cardIcon: Icons.exit_to_app,
                                title: 'Absen Masuk',
                                subtitle: 'Sebelum Jam Kerja',
                                screenWidget: Absensi(
                                  inOut: '1',
                                ),
                              ),
                              SizedBox(width: 20.0),
                              Menu(
                                cardColor: LightColors.kRed,
                                cardIcon: Icons.redo,
                                title: 'Absen Keluar',
                                subtitle: 'Sesudah Jam Kerja',
                                screenWidget: Absensi(
                                  inOut: '0',
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: <Widget>[
                              Menu(
                                cardColor: LightColors.kDarkYellow,
                                cardIcon: Icons.notification_important,
                                title: 'SOS',
                                subtitle: 'Kondisi Darurat',
                                screenWidget: Absensi(
                                  inOut: '1',
                                ),
                              ),
                              SizedBox(width: 20.0),
                              Menu(
                                cardColor: LightColors.kBlue,
                                cardIcon: Icons.location_history,
                                title: 'Check Point',
                                subtitle: 'Periksa Pos',
                                screenWidget: Absensi(
                                  inOut: '1',
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Menu extends StatelessWidget {
  final Color cardColor;
  final IconData cardIcon;
  final String title;
  final String subtitle;
  final Widget screenWidget;

  Menu(
      {this.cardColor,
      this.cardIcon,
      this.title,
      this.subtitle,
      this.screenWidget});
  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 1,
      child: GestureDetector(
        onTap: () {
          Route route = MaterialPageRoute(builder: (context) {
            return screenWidget;
          });

          Navigator.of(context).push(route);
        },
        child: Container(
          margin: EdgeInsets.symmetric(vertical: 10.0),
          padding: EdgeInsets.all(15.0),
          height: 200,
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(30.0),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Icon(
                  cardIcon,
                  size: 85,
                  color: Colors.white70,
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 14.0,
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 12.0,
                      color: Colors.white54,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:gms_mobile/component/theme/light_colors.dart';
import 'package:gms_mobile/component/widgets/back_button.dart';

class Empty extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: LightColors.kLightYellow,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                MyBackButton(),
                SizedBox(
                  height: 30.0,
                ),
                Text(
                  "UNAVAILABLE",
                  style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.w700),
                ),
                Text(
                  "Coming Soon",
                  style: TextStyle(
                    fontSize: 18.0,
                    color: Colors.grey,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                Center(
                  child: Text("Menu belum tersedia"),
                )
              ],
            ),
          ),
        ));
  }
}

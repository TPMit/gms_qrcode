import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'page/login_page.dart';
import 'page/home.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'component/theme/light_colors.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    //systemNavigationBarColor: LightColors.kLightYellow, // navigation bar color
    statusBarColor: Color(0xffffb969), // status bar color
  ));
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Future<bool> showLoginPage() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    String user = sharedPreferences.getString('nik');
    return user == null;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'TPM Guard System',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.amber,
          textTheme: Theme.of(context).textTheme.apply(
              bodyColor: LightColors.kDarkBlue,
              displayColor: LightColors.kDarkBlue,
              fontFamily: 'Poppins'),
        ),
        home: FutureBuilder<bool>(
          future: showLoginPage(),
          builder: (buildContext, snapshot) {
            if (snapshot.hasData) {
              if (snapshot.data) {
                return LoginPage();
              }
              return Home();
            } else {
              return Center(child: CircularProgressIndicator());
            }
          },
        ));
  }
}

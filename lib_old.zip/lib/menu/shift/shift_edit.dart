import 'package:flutter/material.dart';
import 'package:gms_mobile/component/theme/light_colors.dart';
import 'package:gms_mobile/component/widgets/back_button.dart';
import 'package:gms_mobile/component/widgets/top_container.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gms_mobile/menu/shift/shift_model.dart';
import 'package:gms_mobile/page/home.dart';
import 'package:http/http.dart' as http;

class Editshift extends StatefulWidget {
  final String nik, name, shiftCode, shift, pattern;

  Editshift(
      {Key key,
      @required this.nik,
      this.name,
      this.shiftCode,
      this.shift,
      this.pattern})
      : super(key: key);
  @override
  _EditshiftState createState() =>
      _EditshiftState(nik, name, shiftCode, shift, pattern);
}

class _EditshiftState extends State<Editshift> {
  String nik, name, shiftCode, shift, pattern;
  _EditshiftState(
      this.nik, this.name, this.shiftCode, this.shift, this.pattern);
  String selectedValue;

  List<DetailShift> _listItem;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    ModelShift.getDetailShift(pattern).then((listItem) {
      setState(() {
        _isLoading = true;
        _listItem = listItem;
        selectedValue = shiftCode;
      });
    });
  }

  Future<http.Response> updateShift(String code) {
    String apiURL = "https://hris.tpm-facility.com/attendance/updateshift";

    return http.post(apiURL, body: {'nik': nik, 'code': code});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: LightColors.kLightYellow,
        body: Column(
          children: [
            SafeArea(
              child: TopContainer(
                height: 150,
                width: MediaQuery.of(context).size.width,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      MyBackButton(),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        name,
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      Text(shiftCode + " - " + shift)
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Shift : ",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: EdgeInsets.only(left: 16, right: 16),
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 1),
                        borderRadius: BorderRadius.circular(15)),
                    child: DropdownButton(
                      value: selectedValue,
                      isExpanded: true,
                      icon: Icon(Icons.arrow_drop_down),
                      iconSize: 25,
                      underline: SizedBox(),
                      //dropdownColor: Colors.grey,
                      hint: Text(shiftCode + " - " + shift),
                      items: (_isLoading != true)
                          ? []
                          : _listItem.map((data) {
                              return DropdownMenuItem(
                                  value: data.shiftCode,
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: Text(data.shiftCode +
                                        " - " +
                                        data.timeIn +
                                        " s/d " +
                                        data.timeOut),
                                  ));
                            }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          print(newValue);
                          selectedValue = newValue;
                        });
                        print(selectedValue);
                      },
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Center(
                    child: ElevatedButton(
                        onPressed: () {
                          updateShift(selectedValue);
                          print("update to " + selectedValue);
                          Fluttertoast.showToast(
                              msg: "Shift $name berhasil diperbarui",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.grey,
                              textColor: Colors.white,
                              fontSize: 16.0);
                          Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(builder: (context) => Home()),
                              (Route<dynamic> route) => false);
                        },
                        style: ElevatedButton.styleFrom(
                            primary: LightColors.kDarkYellow),
                        child: Text("Simpan")),
                  )
                ],
              ),
            )
          ],
        ));
  }
}

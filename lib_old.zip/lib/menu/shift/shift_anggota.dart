import 'package:flutter/material.dart';
import 'package:gms_mobile/component/theme/light_colors.dart';
import 'package:gms_mobile/component/widgets/back_button.dart';
import 'package:gms_mobile/menu/shift/shift_add.dart';
import 'package:gms_mobile/menu/shift/shift_model.dart';
import 'package:gms_mobile/menu/shift/shift_edit.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Listshift extends StatefulWidget {
  @override
  _ListshiftState createState() => _ListshiftState();
}

class _ListshiftState extends State<Listshift> {
  List<Shifts> _shifts;
  SharedPreferences _prefs;
  String _idposition, _idsite, _pattern;
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((prefs) {
      setState(() => this._prefs = prefs);
      this._idsite = this._prefs.getString('idsite') ?? "0";
      this._idposition = this._prefs.getString("idposition") ?? "0";
      Services.getShifts(_idsite).then((shifts) {
        setState(() {
          _shifts = shifts;
          this._pattern = _shifts[0].shiftPattern;
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: LightColors.kLightYellow,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    MyBackButton(),
                    Text(
                      "Daftar Shifts",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                SizedBox(
                  height: 15.0,
                ),
                null == _shifts
                    ? Center(
                        child: Text(
                            "Belum ada daftar shift, Lakukan penambahan shift untuk anggota!"),
                      )
                    : Flexible(
                        child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: null == _shifts ? 0 : _shifts.length,
                            itemBuilder: (BuildContext context, int index) {
                              Shifts shifts = _shifts[index];
                              return Card(
                                //DENGAN MARGIN YANG DISESUAIKAN
                                margin: EdgeInsets.only(
                                    top: 15, left: 15, right: 15),
                                //DENGAN KETEBALAN AGAR MEMBENTUK SHADOW SENILAI 8
                                elevation: 8,
                                //CHILD DARI CARD MENGGUNAKAN LISTTILE AGAR LEBIH MUDAH MENGATUR AREANYA
                                //KARENA SECARA DEFAULT LISTTILE TELAH TERBAGI MENJADI 3 BAGIAN
                                //POSISI KIRI (LEADING), TENGAH (TITLE), BAWAH TENGAH (SUBTITLE) DAN KANAN(TRAILING)
                                //SEHINGGA KITA HANYA TINGGAL MEMASUKKAN TEKS YANG SESUAI
                                child: ListTile(
                                  leading: Text(
                                    shifts.codeShift,
                                    style: TextStyle(
                                        fontSize: 20, color: Colors.lightGreen),
                                  ),
                                  title: Text(
                                    shifts.name,
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  subtitle: Row(
                                    children: [
                                      Icon(
                                        Icons.access_time,
                                        size: 12,
                                      ),
                                      Text(" " +
                                          shifts.timeIn +
                                          " - " +
                                          shifts.timeOut),
                                    ],
                                  ),
                                  trailing: (_idposition != "2")
                                      ? SizedBox()
                                      : GestureDetector(
                                          onTap: () {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) {
                                              return Editshift(
                                                nik: shifts.nik,
                                                name: shifts.name,
                                                shiftCode: shifts.codeShift,
                                                shift: shifts.timeIn +
                                                    " s/d " +
                                                    shifts.timeOut,
                                                pattern: shifts.shiftPattern,
                                              );
                                            }));
                                          },
                                          child: Text(
                                            "Edit",
                                            style: TextStyle(
                                                color: Colors.lightGreen),
                                          ),
                                        ),
                                ),
                              );
                            }),
                      ),
                SizedBox(
                  height: 28.0,
                ),
              ],
            ),
          ),
        ),
        floatingActionButton: (_idposition != "2")
            ? SizedBox()
            : FloatingActionButton.extended(
                onPressed: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) {
                    return Addshift(idSite: _idsite, pattern: _pattern);
                  }));
                },
                label: const Text('Tambahkan Data'),
                icon: const Icon(Icons.add),
                backgroundColor: LightColors.kDarkYellow,
              ));
  }
}

import 'package:flutter/material.dart';
import 'package:gms_mobile/component/theme/light_colors.dart';
import 'package:gms_mobile/component/widgets/back_button.dart';
import 'package:gms_mobile/component/widgets/top_container.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gms_mobile/menu/shift/shift_model.dart';
import 'package:gms_mobile/page/home.dart';
import 'package:http/http.dart' as http;

class Addshift extends StatefulWidget {
  final String idSite, pattern;

  Addshift({Key key, @required this.idSite, @required this.pattern})
      : super(key: key);
  @override
  _AddshiftState createState() => _AddshiftState(idSite, pattern);
}

class _AddshiftState extends State<Addshift> {
  String idSite, pattern;
  _AddshiftState(this.idSite, this.pattern);
  String selectedNik, selectedCode;

  List<Securities> _listEmployee;
  List<DetailShift> _listShift;
  bool _isLoadingShift = false;
  bool _isLoadingEmployee = false;

  @override
  void initState() {
    super.initState();
    ModelShift.getDetailShift(pattern).then((listshift) {
      setState(() {
        _isLoadingShift = true;
        _listShift = listshift;
      });
    });
    ModelSiteEmployees.getSecurities(idSite).then((listemployee) {
      setState(() {
        _isLoadingEmployee = true;
        _listEmployee = listemployee;
      });
    });
  }

  Future<http.Response> addShift(String nik, String code) {
    String apiURL = "https://hris.tpm-facility.com/attendance/addshift";

    return http.post(apiURL, body: {'nik': nik, 'code': code});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: LightColors.kLightYellow,
        body: Column(
          children: [
            SafeArea(
              child: TopContainer(
                height: 150,
                width: MediaQuery.of(context).size.width,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      MyBackButton(),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        "Tambahkan Shift",
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Shift : ",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: EdgeInsets.only(left: 16, right: 16),
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 1),
                        borderRadius: BorderRadius.circular(15)),
                    child: DropdownButton(
                      value: selectedCode,
                      isExpanded: true,
                      isDense: false,
                      icon: Icon(Icons.arrow_drop_down),
                      iconSize: 25,
                      underline: SizedBox(),
                      //dropdownColor: Colors.grey,
                      hint: Text("Pilih shift"),
                      items: (_isLoadingShift != true)
                          ? []
                          : _listShift.map((shift) {
                              return DropdownMenuItem(
                                  value: shift.shiftCode,
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: Text(shift.shiftCode +
                                        " - " +
                                        shift.timeIn +
                                        " s/d " +
                                        shift.timeOut),
                                  ));
                            }).toList(),
                      onChanged: (newCode) {
                        setState(() {
                          print(newCode);
                          selectedCode = newCode;
                        });
                        print(selectedCode);
                      },
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Text(
                    "Nama Security : ",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: EdgeInsets.only(left: 16, right: 16),
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 1),
                        borderRadius: BorderRadius.circular(15)),
                    child: DropdownButton(
                      value: selectedNik,
                      isExpanded: true,
                      isDense: false,
                      icon: Icon(Icons.arrow_drop_down),
                      iconSize: 25,
                      underline: SizedBox(),
                      //dropdownColor: Colors.grey,
                      hint: Text("Pilih Security"),
                      items: (_isLoadingEmployee != true)
                          ? []
                          : _listEmployee.map((data) {
                              return DropdownMenuItem(
                                  value: data.nik,
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: Text(data.name),
                                  ));
                            }).toList(),
                      onChanged: (newNik) {
                        setState(() {
                          print(newNik);
                          selectedNik = newNik;
                        });
                        print(selectedNik);
                      },
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Center(
                    child: ElevatedButton(
                        onPressed: () {
                          addShift(selectedNik, selectedCode);
                          print("add to " + selectedCode);
                          Fluttertoast.showToast(
                              msg: "Shift berhasil ditambah",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.grey,
                              textColor: Colors.white,
                              fontSize: 16.0);
                          Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(builder: (context) => Home()),
                              (Route<dynamic> route) => false);
                        },
                        style: ElevatedButton.styleFrom(
                            primary: LightColors.kDarkYellow),
                        child: Text("Tambahkan")),
                  )
                ],
              ),
            )
          ],
        ));
  }
}

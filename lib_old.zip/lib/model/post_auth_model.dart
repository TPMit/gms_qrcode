import 'dart:convert';

import 'package:http/http.dart' as http;

class PostResult {
  String nik;
  String name;
  String email;
  String idsite;
  String idposition;

  PostResult({this.nik, this.name, this.email, this.idsite, this.idposition});

  //membuat object dari jsonobject
  factory PostResult.createPostResult(Map<String, dynamic> object) {
    return PostResult(
        nik: object['nik'].toString(),
        name: object['name'],
        email: object['email'],
        idsite: object['id_site'].toString(),
        idposition: object['id_position'].toString());
  }

  //menghubungkan k api
  static Future<PostResult> connectToApi(String email, String password) async {
    String apiURL = "https://hris.tpm-facility.com/rest/employees_auth";

    var apiResult =
        await http.post(apiURL, body: {"email": email, "password": password});
    var jsonObject = json.decode(apiResult.body);

    return PostResult.createPostResult(jsonObject);
  }
}

import '../model/add_tamu_model.dart';

abstract class AddTamuState {
  void refreshData(AddTamuModel addTamuModel);
  void onSuccess(String success);
  void onError(String error);
}

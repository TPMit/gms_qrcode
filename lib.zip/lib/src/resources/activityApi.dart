// ignore_for_file: file_names, avoid_print

import '../model/activity_model.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'dart:convert';

import '../model/visitor_model.dart';

class ActivityServices {
  static Future<List<AcitivityModel>> getData(String idsite) async {
    print(idsite);
    try{
      final response = await http.get(Uri.parse(
          'https://gmsqr.tpm-security.com/attendance/listactivitiesidsite/' +
              idsite));
      print(response.body);
      return compute(parseData, response.body);
    } catch (e) {
      return [];
    }
  }

  static List<AcitivityModel> parseData(String responseBody) {
    final parsed = jsonDecode(responseBody).cast<Map<String, dynamic>>();

    return parsed
        .map<AcitivityModel>((json) => AcitivityModel.fromJson(json))
        .toList();
  }

  static Future<List<VisitorModel>> getDataTamu(String idsite) async {
    print(idsite);
    try {
      final response = await http.get(Uri.parse(
          'https://gmsqr.tpm-security.com/attendance/listactivitiesvisitor/' +
              idsite));

      return compute(parseDataTamu, response.body);
    } catch (e) {
      return [];
    }
  }

  static List<VisitorModel> parseDataTamu(String responseBody) {
    final parsed = jsonDecode(responseBody).cast<Map<String, dynamic>>();

    return parsed
        .map<VisitorModel>((json) => VisitorModel.fromJson(json))
        .toList();
  }
}
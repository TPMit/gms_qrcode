
// ignore_for_file: file_names, avoid_print

import '../model/list_absen_model.dart';
import 'package:http/http.dart' as http;

import '../model/list_absensi_status.dart';
import '../model/list_member_model.dart';
// import '../model/list_penghuni.dart';
import '../response/penghuni_master_response.dart';

class ListAbsenService {
  static Future<List<ListAbsenModel>> get(String param) async {
    print('get list absen');
    try {
      print("idniknya $param");
      final response = await http.get(Uri.parse(
          "https://gmsqr.tpm-security.com/attendance/listabsenidsite/$param"));
      if (200 == response.statusCode) {
        final List<ListAbsenModel> data = listAbsenModelFromJson(response.body);
        return data;
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }
  }

  static Future<List<ListMemberModel>> getMember(String param) async {
    try {
      print(param);
      final response = await http.get(Uri.parse(
          "https://gmsqr.tpm-security.com/attendance/listmember/$param"));
      if (200 == response.statusCode) {
        final List<ListMemberModel> data =
            listMemberModelFromJson(response.body);
        return data;
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }
  }

  static Future<List<ListPenghuniResponse>> getMemberPenghuni(String query) async {
    try {
      print(query);
      if(query != ''){
        final response = await http.get(Uri.parse(
            "https://gmsqr.tpm-security.com/attendance/listmemberPenghuni/?param=$query"));
          print(response.body);
        if (200 == response.statusCode) {
          final List<ListPenghuniResponse> data =
              listPenghuniResponseFromJson(response.body);
          return data;
        } else {
          return [];
        }
      }else{
        final response = await http.get(Uri.parse(
            "https://gmsqr.tpm-security.com/attendance/listmemberPenghuni/"));
        // print(response.body);
        if (200 == response.statusCode) {
          final List<ListPenghuniResponse> data =
              listPenghuniResponseFromJson(response.body);
          return data;
        } else {
          return [];
        }
      }
    } catch (e) {
      return [];
    }
  }

  static Future<List<ListAbsensiStatus>>? getAbsensiStatus() async {
    try {
      final response = await http.get(Uri.parse(
          "https://gmsqr.tpm-security.com/attendance/listabsenstatus"));
      if (200 == response.statusCode) {
        final List<ListAbsensiStatus> data =
            listAbsensiStatusFromJson(response.body);
        return data;
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }
  }
}

// ignore_for_file: file_names

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../model/emergency_contact_model.dart';

class ContactServices {
  static Future<List<ContactModel>> getData() async {
    final response = await http.get(Uri.parse(
        'https://gmsqr.tpm-security.com/attendance/listemergencycontact'));

    return compute(parseData, response.body);
  }

  static List<ContactModel> parseData(String responseBody) {
    final parsed = jsonDecode(responseBody).cast<Map<String, dynamic>>();

    return parsed
        .map<ContactModel>((json) => ContactModel.fromJson(json))
        .toList();
  }
}
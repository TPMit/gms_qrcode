class AcitivityModel {
  AcitivityModel({
    required this.activityid,
    required this.name,
    required this.activity,
    required this.dateTime,
    required this.images,
  });

  String activityid;
  String name;
  String activity;
  DateTime dateTime;
  String images;

  factory AcitivityModel.fromJson(Map<String, dynamic> json) => AcitivityModel(
        activityid: json["activityid"],
        name: json["name"],
        activity: json["activity"],
        dateTime: DateTime.parse(json["date_time"]),
        images: json["images"],
      );

  Map<String, dynamic> toJson() => {
        "activityid": activityid,
        "name": name,
        "activity": activity,
        "date_time": dateTime.toIso8601String(),
        "images": images,
      };
}

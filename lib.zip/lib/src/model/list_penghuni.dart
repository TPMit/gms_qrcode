class ListPenghuniModel {
  String idPenghuni;
  String blok;
  String kategori;
  String penghuni;

  ListPenghuniModel({required this.idPenghuni,required this.blok,required this.kategori,required this.penghuni});
}
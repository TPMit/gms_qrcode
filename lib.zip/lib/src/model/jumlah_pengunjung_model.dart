class JumlahPengunjung {
  String total;

  JumlahPengunjung({required this.total});
}

class JumlahPengunjungModel{
  bool isLoading = false;
  bool isSuccess = false;
  List<JumlahPengunjung> rasioGrade = <JumlahPengunjung>[];
}
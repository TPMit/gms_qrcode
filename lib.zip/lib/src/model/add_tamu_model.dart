import 'package:flutter/material.dart';
import 'package:security_tpm/src/model/list_penghuni.dart';

import '../response/penghuni_master_response.dart';

class AddTamuModel{
  bool isLoading = false;
  bool isSuccess = false;
  String idPenghuni = '';
  TextEditingController tanggalController = TextEditingController();
  TextEditingController waktuController = TextEditingController();
  TextEditingController rumahController = TextEditingController();
  List<ListPenghuniModel> listPenghuni = <ListPenghuniModel>[];
  List<ListPenghuniResponse> penghunis = <ListPenghuniResponse>[];
}
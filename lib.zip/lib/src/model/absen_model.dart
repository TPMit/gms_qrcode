class AbsenModel {
  bool isloading = false;
  bool isSuccess = false;
  bool location = false;
  String attrId = "";
  String hasilQr = "";
  double? latitude;
  double? longitude;
  String desc = "";
}

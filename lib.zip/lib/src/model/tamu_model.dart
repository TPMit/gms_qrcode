import 'package:flutter/material.dart';

class TamuModel {
  bool isErrorUsername = false;
  bool isErrorEmail = false;
  bool isloading = false;
  bool isSuccess = false;
  String usernameError = "";
  String emailError = "";
  String hasilQr = "";
  late int isKondusif;
  String desc = "";
  final TextEditingController username = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController sekolahController = TextEditingController();
}
// ignore_for_file: file_names

const String idUser = '0';
const String nik = '0';
const String namaUser = "murid";
const String idSite = "0";
const String idPosition = "1";

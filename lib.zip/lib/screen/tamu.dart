// ignore_for_file: avoid_print

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

import '../src/model/visitor_model.dart';
import '../src/resources/activityApi.dart';
import '../src/resources/session.dart';
import 'fragment/activity/dialog_tamu_detail.dart';
import 'fragment/component/background.dart';
import 'package:get_storage/get_storage.dart';
import '../helper/getStorage.dart' as constants;
import 'fragment/tamu_add.dart';

class TamuScreen extends StatefulWidget {
  const TamuScreen({Key? key}) : super(key: key);

  @override
  State<TamuScreen> createState() => _TamuScreenState();
}
  int idUser = 0;

class _TamuScreenState extends State<TamuScreen> {
  @override
  void initState() {
    super.initState();
    Session.getId().then((value) {
      setState(() {
        idUser = int.parse(value!);
      });
      print('===');
    });
      print(Session.getId());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Aktifitas Tamu hari ini'),
        leading: IconButton(
            onPressed: () {
              Navigator.pushNamed(context, "/home");
            },
            icon: const Icon(LineIcons.arrowLeft)),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => TamuAddScreen(idUser: idUser,)));
              },
              icon: const FaIcon(FontAwesomeIcons.plus))
        ],
      ),
      body: Stack(
        children: [
          const CustomBackground(),
          FutureBuilder<List<VisitorModel>>(
            future: ActivityServices.getDataTamu(
                GetStorage().read(constants.idSite)),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return const Center(
                  child: Text('An error has occurred!'),
                );
              } else if (snapshot.hasData && snapshot.data != null) {
                return ActivityList(activities: snapshot.data!);
              } else {
                return const Center(
                  child: Text(
                    'Tambahkan aktifitas untuk hari ini.',
                    style: TextStyle(color: Colors.white38),
                  ),
                );
              }
            },
          )
        ],
      ),
    );
  }
}

class ActivityList extends StatelessWidget {
  const ActivityList({Key? key, required this.activities}) : super(key: key);
  final List<VisitorModel> activities;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: activities.length,
        itemBuilder: (context, index) {
          VisitorModel data = activities[index];
          return GestureDetector(
            onTap: () => showDialog(
                context: context,
                builder: (context) => DialogTamuDetail(
                      pengunjung: data.tamu,
                      image: data.images,
                      name: data.name,
                      activity: data.blok + '-' + data.penghuni,
                      waktu: data.tanggal + ' ' + data.jam,
                      status: data.status,
                      idTamu: data.id,
                    )),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 3),
              margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 8),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5), color: Colors.white),
              child: Column(
                children: [
                  Text(
                    data.blok + '-' + data.penghuni,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text('ditambahkan pada ' +
                      DateFormat('kk:mm').format(data.dateTime))
                ],
              ),
            ),
          );
        });
  }
}

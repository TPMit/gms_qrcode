import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

import '../src/model/activity_model.dart';
import '../src/resources/activityApi.dart';
import '../src/resources/session.dart';
import 'fragment/activity/dialogactivitydetail.dart';
import 'fragment/activity_add.dart';
import 'fragment/component/background.dart';

class Activities extends StatefulWidget {
  const Activities({ Key? key }) : super(key: key);

  @override
  State<Activities> createState() => _ActivitiesState();
}

class _ActivitiesState extends State<Activities> {
  late int idUser = 0;

  @override
  void initState() {
    super.initState();
    Session.getId().then((value) {
      setState(() {
        idUser = int.parse(value!);
      });
      print('===');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Aktifitas Hari Ini'),
        leading: IconButton(
            onPressed: () {
              Navigator.pushNamed(context, "/home");
            },
            icon: const Icon(LineIcons.arrowLeft)),
        actions: [
          IconButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (context) => const AddActivityScreen());
              },
              icon: const FaIcon(FontAwesomeIcons.plus))
        ],
      ),
      body: Stack(
        children: [
          const CustomBackground(),
          FutureBuilder<List<AcitivityModel>>(
            future: ActivityServices.getData(idUser.toString()),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return const Center(
                  child: Text('An error has occurred!'),
                );
              } else if (snapshot.hasData && snapshot.data != []) {
                return ActivityList(activities: snapshot.data!);
              } else {
                return const Center(
                  child: Text(
                    'Tambahkan aktifitas untuk hari ini.',
                    style: TextStyle(color: Colors.white38),
                  ),
                );
              }
            },
          )
        ],
      ),
    );
  }
}

class ActivityList extends StatelessWidget {
  const ActivityList({Key? key, required this.activities}) : super(key: key);
  final List<AcitivityModel> activities;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: activities.length,
        itemBuilder: (context, index) {
          AcitivityModel data = activities[index];
          return GestureDetector(
            onTap: () => showDialog(
                context: context,
                builder: (context) => DialogActivityDetail(
                      image: data.images,
                      name: data.name,
                      activity: data.activity,
                    )),
            child: Container(
              padding:const EdgeInsets.symmetric(vertical: 8, horizontal: 3),
              margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 8),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5), color: Colors.white),
              child: Column(
                children: [
                  Text(
                    data.activity,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text('ditambahkan pada ' +
                      DateFormat('kk:mm').format(data.dateTime))
                ],
              ),
            ),
          );
        });
  }
}

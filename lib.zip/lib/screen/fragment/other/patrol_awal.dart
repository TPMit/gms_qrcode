// ignore_for_file: import_of_legacy_library_into_null_safe, prefer_is_empty, avoid_print

import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ionicons/ionicons.dart';
import 'package:security_tpm/screen/fragment/component/ligh_colors.dart';
import 'package:security_tpm/src/model/patrol_model.dart';
import 'package:security_tpm/src/state/patrol_state.dart';

import '../../../src/model/list_checkpoint_model.dart';
import '../../../src/presenter/patrol_presenter.dart';
import '../../../src/resources/checkpointApi.dart';
import '../../../src/resources/session.dart';
import '../../patrol.dart';
import '../component/clipath.dart';
import '../component/patrol_list.dart';
import '../loading.dart';
import 'package:security_tpm/helper/getStorage.dart' as constant;

class PatrolAwalScreen extends StatefulWidget {
  const PatrolAwalScreen({Key? key}) : super(key: key);

  @override
  _PatrolAwalScreenState createState() => _PatrolAwalScreenState();
}


class _PatrolAwalScreenState extends State<PatrolAwalScreen>
    with SingleTickerProviderStateMixin
    implements PatrolState {
  String barcode = "";
  late String idUser = "";
  late TabController tabController;
  late PatrolModel _patrolModel;
  late PatrolPresenter _patrolPresenter;

  _PatrolAwalScreenState() {
    _patrolPresenter = PatrolPresenter();
  }

  @override
  void initState() {
    super.initState();
    _patrolPresenter.view = this;
    tabController = TabController(length: 2, vsync: this);
    Session.getId().then((value) {
      setState(() {
        idUser = value.toString();
        print('===');
        _patrolPresenter.newCheckpoint(value.toString(), GetStorage().read(constant.idSite));
      });
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _patrolModel.isloading
          ? const Loading()
          : Stack(
              children: [
                SafeArea(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: 300.0,
                        padding: const EdgeInsets.only(bottom: 0),
                        child: Stack(
                          children: <Widget>[
                            ClipPath(
                              clipper: TClipper(),
                              child: Container(
                                width: MediaQuery.of(context).size.width,
                                height: 260.0,
                                decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                  colors: [
                                    Color(0xff25509e),
                                    LightColors.kDarkYellow,
                                  ],
                                  begin: FractionalOffset(0.0, 0.0),
                                  end: FractionalOffset(1.0, 0.0),
                                )),
                              ),
                            ),
                            Positioned(
                              top: 10,
                              child: IconButton(
                                icon: const Icon(
                                  Ionicons.arrow_back,
                                  color: Colors.white,
                                ),
                                iconSize: 24,
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                              ),
                            ),
                            Positioned(
                              top: 90,
                              left: 35,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text(
                                    'Check Point Patroli',
                                    style: TextStyle(
                                        fontSize: 25,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  const Padding(
                                    padding: EdgeInsets.symmetric(vertical: 12),
                                    child: Text(
                                      "klik tombol 'tambah' untuk menambahkan patroli hari ini",
                                      style: TextStyle(
                                          fontSize: 12, color: Colors.white),
                                    ),
                                  ),
                                  Center(
                                    child: InkWell(
                                      splashColor: const Color(0xff7474BF),
                                      onTap: () async {
                                        print(_patrolModel.idCheckpoint);
                                        Navigator.push(context, MaterialPageRoute(
                                          builder: (context) => 
                                           PatrolScreen(idCheckout: _patrolModel.idCheckpoint)
                                        ));
                                      },
                                      child: Container(
                                        margin:
                                            const EdgeInsets.only(top: 10.0),
                                        height: 43,
                                        width:
                                            MediaQuery.of(context).size.width /
                                                1.2,
                                        decoration: const BoxDecoration(
                                            boxShadow: [
                                              BoxShadow(
                                                  color: Colors.black26,
                                                  offset: Offset(0, 28),
                                                  blurRadius: 40,
                                                  spreadRadius: -12)
                                            ],
                                            color: Colors.green,
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(10))),
                                        child: const Center(
                                          child: Text(
                                            "checkpoint",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Center(
                        child: Padding(
                          padding: EdgeInsets.only(top: 18),
                          child: Text(
                            "Daftar Patroli Hari Ini:",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.black),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          // padding: EdgeInsets.all(20),
                          margin: const EdgeInsets.all(15),
                          child: FutureBuilder<List<ListCheckPointModel>>(
                            future:
                                ListCheckPointService.get(idUser.toString()),
                            builder: (context, snapshot) {
                              if (snapshot.hasError) {
                                return const Center(
                                  child: Text('An error has occurred!'),
                                );
                              } else if (snapshot.hasData &&
                                  snapshot.data!.length > 0) {
                                return CheckPointList(
                                    checkpoints: snapshot.data!);
                              } else {
                                return const Center(
                                  child: Text(
                                    'Tambahkan checkpoint untuk hari ini.',
                                    style: TextStyle(color: Colors.black),
                                  ),
                                );
                              }
                            },
                          ),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
    );
  }

  @override
  void onError(String error) {
    
  }

  @override
  void onSuccess(String success) {
    
  }

  @override
  void onSuccessUnCondusif(String success) {
    
  }

  @override
  void refreshData(PatrolModel patrolModel) {
    setState(() {
      _patrolModel = patrolModel;
    });
  }

  @override
  void scan(String idTag) {
    
  }

  @override
  void showDeskripsi(BuildContext context) {
    
  }

  @override
  void showstatusKondisi(BuildContext context) {
    
  }
}
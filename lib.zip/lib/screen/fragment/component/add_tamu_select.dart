// ignore_for_file: no_logic_in_create_state, avoid_print

import 'package:flutter/material.dart';
import 'package:security_tpm/src/model/add_tamu_model.dart';

class SelectTamu extends StatefulWidget {
  final AddTamuModel addTamuModel;

  const SelectTamu({Key? key, required this.addTamuModel}) : super(key: key);

  @override
  _SelectTamuState createState() => _SelectTamuState(addTamuModel);
}

class _SelectTamuState extends State<SelectTamu> {
  late AddTamuModel _addTamuModel;

  _SelectTamuState(AddTamuModel addTamuModel) {
    _addTamuModel = addTamuModel;
    print(addTamuModel);
  }

  @override
  Widget build(BuildContext context) {
   return Scaffold(
     appBar: AppBar(
       title: const Text('pilih Tujuan'),
     ), 
     body: ListView.builder(
        itemCount: _addTamuModel.penghunis.length,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        padding: const EdgeInsets.only(left: 20, right: 20),
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
        onTap: () {
          setState(() {
            Navigator.pop(context, index);
          });
          Navigator.pop(context);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 8),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5), color: Colors.white),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              _addTamuModel.penghunis[index].blok + ' - ' + _addTamuModel.penghunis[index].penghuni,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ),
      );
        },
      ),
   );
  }
}